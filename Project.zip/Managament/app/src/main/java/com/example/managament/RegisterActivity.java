package com.example.managament;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText idText;
    EditText passwordText;
    EditText nameText;
    EditText ageText;
    Button registerButton1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        idText = (EditText)findViewById(R.id.idText);
        passwordText = (EditText)findViewById(R.id.passwordText);
        nameText = (EditText)findViewById(R.id.nameText);
        ageText = (EditText)findViewById(R.id.ageText);

        registerButton1 = (Button)findViewById(R.id.registerButton1);

        registerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = nameText.getText().toString();
                Toast.makeText(getApplicationContext(),name + "님 가입완료!",Toast.LENGTH_LONG).show();
                Intent loginIntent = new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(loginIntent);


            }
        });



    }
}
