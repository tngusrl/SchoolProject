package com.example.managament;

import android.graphics.drawable.Drawable;

public class ListViewItem {

    private Drawable bookCover;
    private String bookTitle;
    private String bookPrice;

    public Drawable getBookCover() {
        return bookCover;
    }

    public void setBookCover(Drawable bookCover) {
        this.bookCover = bookCover;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookPrice() {
        return bookPrice;
    }

    public void setBookPrice(String bookPrice) {
        this.bookPrice = bookPrice;
    }
}
