package com.example.managament;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class SellFragment extends Fragment {

    Button btn;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_sell, null);

        ListView listView;
        ListViewAdapter adapter;

        adapter = new ListViewAdapter();

        listView = (ListView)view.findViewById(R.id.listview1);
        listView.setAdapter(adapter);

        adapter.addItem(ContextCompat.getDrawable(getContext(),R.drawable.c),"도서명 : 열혈 TCP/IP 소켓 프로그래밍","저자명 : 윤성우");
        adapter.addItem(ContextCompat.getDrawable(getContext(),R.drawable.tcp),"도서명 : 열혈 C 프로그래밍","저자명 : 이용찬");


        btn = (Button)view.findViewById(R.id.button2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity().getApplicationContext(),"로그인 성공",Toast.LENGTH_LONG).show();
            }
        });

        return view;
    }
}

