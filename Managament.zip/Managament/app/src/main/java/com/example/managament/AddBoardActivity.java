package com.example.managament;

import android.app.ActionBar;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


public class AddBoardActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner spinner;
    String[] item;
    Bitmap bitmap;
    Button searchButton, boardRegisterButton;
    String filed, searchName;
    EditText search_name;
    TextView textView;
    String fileName;
    BitmapDrawable bdrawable;
    String a1,a2,a3,a4,a5,a6,a7;

    TextView t1, t2, t3, t4;

    final int btn333 = 0x8000;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_board);

        spinner = (Spinner) findViewById(R.id.spinner);
        searchButton = (Button) findViewById(R.id.search_button);
        search_name = (EditText) findViewById(R.id.search_name);
        textView = (TextView) findViewById(R.id.bookprice);
        boardRegisterButton = findViewById(R.id.BoardRegisterButton);

        t1 = (TextView) findViewById(R.id.bookname);
        t2 = (TextView) findViewById(R.id.author);
        t3 = (TextView) findViewById(R.id.publisher);
        t4 = (TextView) findViewById(R.id.bookprice);

        final LinearLayout layout = (LinearLayout) findViewById(R.id.layout1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);


        final ArrayList<Thread> threads = new ArrayList<Thread>();

        try {
            //imageView.setImageBitmap(bitmap);
            spinner.setOnItemSelectedListener(this);

            item = new String[]{"도서명", "저자명", "발행처", "발행연도"};

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

            spinner.setAdapter(adapter);

            searchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    layout.removeAllViews();

                    searchName = search_name.getText().toString();

                    Response.ErrorListener errorListener= new Response.ErrorListener(){
                        @Override
                        public void onErrorResponse(VolleyError error){
                            Log.d("e","================= error!!" + error.getMessage());
                        }
                    };

                    Response.Listener<String> responseLister = new Response.Listener<String>() {

                        @Override
                        public void onResponse(String response) {
                            try {

                                final JSONArray jsonArray = new JSONArray(response);
                                final Button btn333333[] = new Button[jsonArray.length()];

                                for (int i = 0; i < jsonArray.length(); i++) {

                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    JSONObject a = jsonObject.getJSONObject("Book");
                                    fileName = a.getString("fileName");

                                    Thread t = new ImageThread(fileName);
                                    t.start();

                                    t.join();

                                    btn333333[i] = new Button(AddBoardActivity.this);
                                    btn333333[i].setText("button" + i);
                                    btn333333[i].setWidth(66);
                                    btn333333[i].setHeight(66);
                                    btn333333[i].setId(btn333 + i);
                                    btn333333[i].setText("");
                                    btn333333[i].setBackground(bdrawable);
                                    btn333333[i].setTag(i);
                                    layout.addView(btn333333[i]);

                                    final int j = i;
                                    btn333333[i].setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {

                                            try {
                                                Button newButton = (Button) v;
                                                position = (Integer) v.getTag();

                                                JSONObject jsonObject = jsonArray.getJSONObject(position);
                                                JSONObject a = jsonObject.getJSONObject("Book");

                                                Toast.makeText(AddBoardActivity.this, Integer.toString(position), Toast.LENGTH_LONG).show();


                                                //a1 = jsonResponse.getString("userID");
                                                a2 = a.getString("fileName");
                                                a3 = a.getString("bookName");
                                                a4 = a.getString("author");
                                                a5 = a.getString("publisher");
                                                a6 = a.getString("bookPrice");
                                                //a7 = jsonResponse.getString("bookState");


                                                t1.setText(a.getString("bookName"));
                                                t2.setText(a.getString("author"));
                                                t3.setText(a.getString("publisher"));
                                                t4.setText(a.getString("bookPrice"));

                                            } catch (Exception e) {

                                                e.printStackTrace();

                                            }
                                        }
                                    });
                                }




                            } catch (Exception e) {

                                e.printStackTrace();

                            }
                        }
                    };

                    SearchRequest searchRequest = new SearchRequest(filed, searchName, responseLister,errorListener);
                    RequestQueue queue = Volley.newRequestQueue(AddBoardActivity.this);
                    queue.add(searchRequest);


                }
            });

            boardRegisterButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Response.Listener<String> responseListener1 = new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {
                                JSONObject jsonResponse = new JSONObject(response);

                                boolean success = jsonResponse.getBoolean("success");

                                if(success){

                                    Intent intent = new Intent(AddBoardActivity.this,BoardListActivity.class);
                                    startActivity(intent);

                                }

                            } catch (Exception e) {

                            }
                        }

                    };

                    SellBoardRequest sellBoardRequest = new SellBoardRequest("tngusrl",a2,a3,a4,a5,a6,"상",responseListener1);
                    RequestQueue queue = Volley.newRequestQueue(AddBoardActivity.this);
                    queue.add(sellBoardRequest);


                }
            });


        } catch (Exception e) {

        }


    }

    public class ImageThread extends Thread {

        String fileName;

        public ImageThread(String tt) {
            this.fileName = tt;
        }

        @Override
        public void run() {
            try {
                URL url = new URL("https://gurwls1307.cafe24.com/" + fileName);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setDoInput(true);
                con.connect();

                InputStream is = con.getInputStream();
                bitmap = BitmapFactory.decodeStream(is);
                bdrawable = new BitmapDrawable(getApplicationContext().getResources(), bitmap);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View v, int i, long l) {

        filed = item[i];
        if (filed.equals("도서명")) {
            filed = "BookName";
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}


