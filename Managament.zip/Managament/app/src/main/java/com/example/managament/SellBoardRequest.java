package com.example.managament;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class SellBoardRequest extends StringRequest {
    final static private String URL = "https://gurwls1307.cafe24.com/SellBoardRegister.php";
    private Map<String, String> parameters;

    public SellBoardRequest(String userID, String fileName, String bookname, String author, String publisher, String bookprice, String bookstate, Response.Listener<String> listener) {
        super(Method.POST, URL, listener, null);
        parameters = new HashMap<>();
        parameters.put("userID", userID);
        parameters.put("fileName", fileName);
        parameters.put("bookname", bookname);
        parameters.put("author", author);
        parameters.put("publisher", publisher);
        parameters.put("bookprice", bookprice);
        parameters.put("bookstate", bookstate);
    }

    @Override
    public Map<String, String> getParams() {
        return parameters;
    }
}
