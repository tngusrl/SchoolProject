package com.example.managament;

import com.android.volley.toolbox.StringRequest;

public class BookInformation {

    public int idx;
    public String filename1;
    public String bookname1;
    public String author1;
    public String publisher1;
    public int bookprice1;

    public int getIdx() {
        return idx;
    }

    public void setIdx(int idx) {
        this.idx = idx;
    }

    public String getFilename1() {
        return filename1;
    }

    public void setFilename1(String filename1) {
        this.filename1 = filename1;
    }

    public String getBookname1() {
        return bookname1;
    }

    public void setBookname1(String bookname1) {
        this.bookname1 = bookname1;
    }

    public String getAuthor1() {
        return author1;
    }

    public void setAuthor1(String author1) {
        this.author1 = author1;
    }

    public String getPublisher1() {
        return publisher1;
    }

    public void setPublisher1(String publisher1) {
        this.publisher1 = publisher1;
    }

    public int getBookprice1() {
        return bookprice1;
    }

    public void setBookprice1(int bookprice1) {
        this.bookprice1 = bookprice1;
    }
}
